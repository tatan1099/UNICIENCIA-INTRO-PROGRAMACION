import pandas as pd
import random

# Clase principal para representar un Pokémon
class Pokemon:
    def __init__(self, id, name, type1, type2, hp, attack, defense, speed):
        self.id = id
        self.name = name
        self.type1 = type1
        self.type2 = type2
        self.hp = hp
        self.attack = attack
        self.defense = defense
        self.speed = speed

    def __str__(self):
        return (f"ID: {self.id}, Name: {self.name}, Type1: {self.type1}, Type2: {self.type2}, "
                f"HP: {self.hp}, Attack: {self.attack}, Defense: {self.defense}, Speed: {self.speed}")

# Clase para gestionar el sistema de Pokémons
class PokemonManager:
    def __init__(self, csv_file):
        self.csv_file = csv_file
        self.pokemons = self.load_pokemons()

    def load_pokemons(self):
        data = pd.read_csv(self.csv_file)
        pokemons = []
        for _, row in data.iterrows():
            pokemons.append(Pokemon(row['ID'], row['Name'], row['Type 1'], row['Type 2'],
                                     row['HP'], row['Attack'], row['Defense'], row['Speed']))
        return pokemons

    def add_pokemon(self, pokemon):
        self.pokemons.append(pokemon)

    def modify_pokemon(self, id, **kwargs):
        for pokemon in self.pokemons:
            if pokemon.id == id:
                for key, value in kwargs.items():
                    setattr(pokemon, key, value)
                return f"Pokemon {id} modificado exitosamente."
        return "Pokemon no encontrado."

    def delete_pokemon(self, id):
        self.pokemons = [pokemon for pokemon in self.pokemons if pokemon.id != id]

    def list_pokemons(self):
        for pokemon in self.pokemons:
            print(pokemon)

# Función para simular una batalla entre dos Pokémons
def battle(pokemon1, pokemon2):
    print(f"¡Batalla entre {pokemon1.name} y {pokemon2.name}!")
    
    # Determinar el orden de ataque según la velocidad
    p1_turn = pokemon1.speed >= pokemon2.speed
    
    while pokemon1.hp > 0 and pokemon2.hp > 0:
        if p1_turn:
            damage = max(0, pokemon1.attack - pokemon2.defense)
            pokemon2.hp -= damage
            print(f"{pokemon1.name} ataca a {pokemon2.name} causando {damage} de daño. {pokemon2.name} tiene {pokemon2.hp} HP restantes.")
        else:
            damage = max(0, pokemon2.attack - pokemon1.defense)
            pokemon1.hp -= damage
            print(f"{pokemon2.name} ataca a {pokemon1.name} causando {damage} de daño. {pokemon1.name} tiene {pokemon1.hp} HP restantes.")
        
        # Cambiar turno
        p1_turn = not p1_turn

    # Determinar el ganador
    if pokemon1.hp > 0:
        print(f"¡{pokemon1.name} gana la batalla!")
        return pokemon1
    else:
        print(f"¡{pokemon2.name} gana la batalla!")
        return pokemon2

# Programa principal
def main():
    manager = PokemonManager('pokemon.csv')

    while True:
        print("\n--- Sistema de Batallas Pokémon ---")
        print("1. Listar Pokémons")
        print("2. Agregar Pokémon")
        print("3. Modificar Pokémon")
        print("4. Eliminar Pokémon")
        print("5. Iniciar Batalla")
        print("6. Salir")

        choice = input("Seleccione una opción: ")

        if choice == '1':
            manager.list_pokemons()
        elif choice == '2':
            id = int(input("ID: "))
            name = input("Nombre: ")
            type1 = input("Tipo 1: ")
            type2 = input("Tipo 2: ")
            hp = int(input("HP: "))
            attack = int(input("Ataque: "))
            defense = int(input("Defensa: "))
            speed = int(input("Velocidad: "))
            manager.add_pokemon(Pokemon(id, name, type1, type2, hp, attack, defense, speed))
            print("Pokémon agregado.")
        elif choice == '3':
            id = int(input("ID del Pokémon a modificar: "))
            updates = {}
            for attr in ['name', 'type1', 'type2', 'hp', 'attack', 'defense', 'speed']:
                value = input(f"{attr.capitalize()} (dejar vacío para no cambiar): ")
                if value:
                    updates[attr] = int(value) if attr in ['hp', 'attack', 'defense', 'speed'] else value
            print(manager.modify_pokemon(id, **updates))
        elif choice == '4':
            id = int(input("ID del Pokémon a eliminar: "))
            manager.delete_pokemon(id)
            print("Pokémon eliminado.")
        elif choice == '5':
            manager.list_pokemons()
            id1 = int(input("ID del primer Pokémon: "))
            id2 = int(input("ID del segundo Pokémon: "))
            pokemon1 = next((p for p in manager.pokemons if p.id == id1), None)
            pokemon2 = next((p for p in manager.pokemons if p.id == id2), None)
            if pokemon1 and pokemon2:
                battle(pokemon1, pokemon2)
            else:
                print("Uno o ambos Pokémons no existen.")
        elif choice == '6':
            print("¡Hasta luego!")
            break
        else:
            print("Opción no válida.")

if __name__ == "__main__":
    main()
